function fun(){
    const email=
}